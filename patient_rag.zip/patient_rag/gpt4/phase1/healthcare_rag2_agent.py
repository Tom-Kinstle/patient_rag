"""
Healthcare RAG Agent System - Implementation based on PROJECT_SPECIFICATION.md
A comprehensive Retrieval-Augmented Generation system for healthcare patient data.

Usage:
    from healthcare_rag_agent import HealthcareRAGAgent
    
    agent = HealthcareRAGAgent()
    agent.load_documents()
    agent.build_index()
    
    result = agent.query("What allergies does patient John Doe have?")
    print(result['response'])
"""

import os
import re
import fitz  # PyMuPDF
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from groq import Groq
import openai
from tqdm import tqdm
from dotenv import load_dotenv
import torch

# Load environment variables
load_dotenv()


@dataclass
class PatientDocument:
    """Data class representing a patient document with metadata."""
    content: str
    patient_number: str
    first_name: str
    last_name: str
    filename: str
    file_path: str


@dataclass
class TextChunk:
    """Data class representing a chunk of text with associated metadata."""
    content: str
    patient_number: str
    first_name: str
    last_name: str
    filename: str
    chunk_id: int
    start_pos: int
    end_pos: int
    metadata: Dict[str, Any]


class HealthcareRAGAgent:
    """
    Complete Healthcare RAG Agent system for querying patient records.
    Handles PDF loading, chunking, embedding, vector storage, and LLM querying.
    """
    
    def __init__(
        self,
        pdf_directory: str = "../../patients_1000",
        db_path: str = "./chroma_db",
        embedding_model: str = "BAAI/bge-large-en-v1.5",
        max_chunk_size: int = 1000,
        chunk_overlap: int = 200,
        batch_size: int = 16,
        temperature: float = 0.1,
        max_tokens: int = 500,
        k: int = 5,
        model_name: str = "gpt-4o"
    ):
        """
        Initialize the Healthcare RAG Agent system.
        
        Args:
            pdf_directory: Path to directory containing patient PDFs
            db_path: Path for ChromaDB storage
            embedding_model: HuggingFace model for embeddings
            max_chunk_size: Maximum size of text chunks
            chunk_overlap: Overlap between chunks
            batch_size: Batch size for processing
            temperature: LLM temperature
            max_tokens: Maximum tokens in LLM response
            k: Number of documents to retrieve
        """
        self.pdf_directory = pdf_directory
        self.db_path = db_path
        self.embedding_model_name = embedding_model
        self.max_chunk_size = max_chunk_size
        self.chunk_overlap = chunk_overlap
        self.batch_size = batch_size
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.k = k
        self.model_name = model_name
        
        # Initialize components
        self.embedding_model = None
        self.vector_db = None
        self.collection = None
        self.llm_client = None
        self.llm_type = None
        
        # System state
        self.is_built = False
        self.documents_loaded = False
        
        # Filename pattern for patient PDFs
        self.filename_pattern = re.compile(
            r"Enhanced_Patient_(\d+)_([^_]+)_([^_.]+)\.pdf"
        )
        
        print(f"Healthcare RAG Agent System initialized")
        print(f"PDF Directory: {self.pdf_directory}")
        print(f"Database Path: {self.db_path}")
        print(f"Chunk Size: {self.max_chunk_size}, Overlap: {self.chunk_overlap}")
    
    def _validate_api_keys(self) -> None:
        """Validate that required API keys are present."""
        groq_key = os.getenv("GROQ_API_KEY")
        openai_key = os.getenv("OPENAI_API_KEY")
        
        if not groq_key and not openai_key:
            raise ValueError("At least one API key (GROQ_API_KEY or OPENAI_API_KEY) must be provided in .env file")
    
    def _initialize_embedding_model(self) -> None:
        """Initialize the sentence transformer model."""
        if self.embedding_model is None:
            print(f"Loading embedding model: {self.embedding_model_name}")
            try:
                # Try CUDA first, fallback to CPU if issues
                device = 'cpu'  # Default to CPU
                if torch.cuda.is_available():
                    try:
                        device = 'cuda'
                        self.embedding_model = SentenceTransformer(self.embedding_model_name, device=device)
                        print(f"Embedding model loaded successfully on CUDA")
                    except Exception as cuda_error:
                        print(f"CUDA failed ({cuda_error}), falling back to CPU...")
                        device = 'cpu'
                        self.embedding_model = SentenceTransformer(self.embedding_model_name, device=device)
                        print(f"Embedding model loaded successfully on CPU")
                else:
                    self.embedding_model = SentenceTransformer(self.embedding_model_name, device=device)
                    print(f"Embedding model loaded successfully on CPU (CUDA not available)")
            except Exception as e:
                raise Exception(f"Failed to load embedding model: {str(e)}")
    
    def _initialize_vector_db(self) -> None:
        """Initialize ChromaDB vector database."""
        if self.vector_db is None:
            try:
                os.makedirs(self.db_path, exist_ok=True)
                self.vector_db = chromadb.PersistentClient(path=self.db_path)
                self.collection = self.vector_db.get_or_create_collection(
                    name="patient_records_agent",
                    metadata={"hnsw:space": "cosine"}
                )
                print(f"ChromaDB initialized at: {self.db_path}")
            except Exception as e:
                raise Exception(f"Failed to initialize ChromaDB: {str(e)}")
    
    def _initialize_llm(self) -> None:
        """Initialize LLM client."""
        if self.llm_client is None:
            self._validate_api_keys()
            
            groq_key = os.getenv("GROQ_API_KEY")
            openai_key = os.getenv("OPENAI_API_KEY")
            
            if openai_key:
                try:
                    openai.api_key = openai_key
                    self.llm_client = openai
                    self.llm_type = "openai"
                    print(f"Initialized OpenAI client for {self.model_name}")
                except Exception as e:
                    print(f"Failed to initialize OpenAI: {str(e)}")
            else:
                raise ValueError(f"OpenAI API key required for {self.model_name} model")
            
            if not self.llm_client:
                raise RuntimeError("No valid LLM client could be initialized")
    
    def _extract_metadata_from_filename(self, filename: str) -> Optional[Dict[str, str]]:
        """Extract patient metadata from filename."""
        match = self.filename_pattern.match(filename)
        if match:
            return {
                "patient_number": match.group(1),
                "first_name": match.group(2),
                "last_name": match.group(3)
            }
        return None
    
    def _extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text content from PDF file."""
        try:
            doc = fitz.open(file_path)
            text_content = ""
            for page_num in range(len(doc)):
                page = doc[page_num]
                text_content += page.get_text()
            doc.close()
            return text_content.strip()
        except Exception as e:
            raise Exception(f"Error reading PDF {file_path}: {str(e)}")
    
    def _find_sentence_boundary(self, text: str, position: int) -> int:
        """Find the nearest sentence boundary to avoid cutting sentences."""
        if position >= len(text):
            return len(text)
        
        # Look for sentence endings within a reasonable window
        search_window = min(100, len(text) - position)
        
        for i in range(position, min(position + search_window, len(text))):
            if text[i] in '.!?':
                if i + 1 < len(text) and text[i + 1] in ' \n\t':
                    return i + 1
        
        # Look backwards if no forward boundary found
        for i in range(position, max(0, position - search_window), -1):
            if text[i] in '.!?':
                if i + 1 < len(text) and text[i + 1] in ' \n\t':
                    return i + 1
        
        return position
    
    def _chunk_document(self, document: PatientDocument) -> List[TextChunk]:
        """Split a patient document into chunks with smart boundary detection."""
        content = document.content
        content_length = len(content)
        
        # If document is shorter than max chunk size, return as single chunk
        if content_length <= self.max_chunk_size:
            return [TextChunk(
                content=content,
                patient_number=document.patient_number,
                first_name=document.first_name,
                last_name=document.last_name,
                filename=document.filename,
                chunk_id=0,
                start_pos=0,
                end_pos=content_length,
                metadata={
                    "patient_number": document.patient_number,
                    "first_name": document.first_name,
                    "last_name": document.last_name,
                    "full_name": f"{document.first_name} {document.last_name}",
                    "filename": document.filename,
                    "file_path": document.file_path,
                    "chunk_id": 0,
                    "total_chunks": 1,
                    "document_length": content_length
                }
            )]
        
        chunks = []
        chunk_id = 0
        start_pos = 0
        
        while start_pos < content_length:
            end_pos = min(start_pos + self.max_chunk_size, content_length)
            
            if end_pos < content_length:
                end_pos = self._find_sentence_boundary(content, end_pos)
            
            chunk_content = content[start_pos:end_pos].strip()
            
            if chunk_content:
                chunk = TextChunk(
                    content=chunk_content,
                    patient_number=document.patient_number,
                    first_name=document.first_name,
                    last_name=document.last_name,
                    filename=document.filename,
                    chunk_id=chunk_id,
                    start_pos=start_pos,
                    end_pos=end_pos,
                    metadata={
                        "patient_number": document.patient_number,
                        "first_name": document.first_name,
                        "last_name": document.last_name,
                        "full_name": f"{document.first_name} {document.last_name}",
                        "filename": document.filename,
                        "file_path": document.file_path,
                        "chunk_id": chunk_id,
                        "document_length": content_length,
                        "chunk_length": len(chunk_content)
                    }
                )
                chunks.append(chunk)
                chunk_id += 1
            
            if end_pos >= content_length:
                break
            
            start_pos = max(end_pos - self.chunk_overlap, start_pos + 1)
        
        # Add total chunks count to all chunk metadata
        for chunk in chunks:
            chunk.metadata["total_chunks"] = len(chunks)
        
        return chunks
    
    def _encode_query(self, query: str) -> np.ndarray:
        """Encode a query string for similarity search with BGE optimization."""
        if not query or not query.strip():
            raise ValueError("Query cannot be empty")
        
        # Add instruction prefix for BGE models to improve retrieval
        prefixed_query = f"Represent this sentence for searching relevant passages: {query.strip()}"
        
        embeddings = self.embedding_model.encode([prefixed_query], normalize_embeddings=True)
        return embeddings[0]
    
    def _extract_patient_info(self, query: str) -> Optional[Dict[str, str]]:
        """Extract patient information from query using advanced pattern matching."""
        query_lower = query.lower()
        
        # Pattern for patient number
        patient_num_pattern = r'patient\s+(?:number\s+)?(\d+)'
        patient_num_match = re.search(patient_num_pattern, query_lower)
        
        if patient_num_match:
            return {
                "type": "patient_number",
                "patient_number": patient_num_match.group(1)
            }
        
        # Enhanced patterns for patient name detection
        name_patterns = [
            r'patient\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'([A-Za-z]+)\s+([A-Za-z]+)(?:\s+patient|\s+has|\s+is)',
            r'for\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'about\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'does\s+([A-Za-z]+)\s+([A-Za-z]+)\s+have',
            r'what\s+(?:are|is)\s+([A-Za-z]+)\s+([A-Za-z]+)(?:\'s|s)?'
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                first_name = match.group(1).strip()
                last_name = match.group(2).strip()
                
                # Enhanced filtering of common words
                common_words = {
                    'patient', 'doctor', 'the', 'has', 'have', 'does', 'what', 
                    'when', 'where', 'how', 'allergies', 'medications', 'taking',
                    'prescribed', 'conditions', 'history', 'medical', 'current'
                }
                
                if (first_name.lower() not in common_words and 
                    last_name.lower() not in common_words and
                    len(first_name) > 2 and len(last_name) > 2):
                    return {
                        "type": "patient_name",
                        "first_name": first_name.title(),
                        "last_name": last_name.title()
                    }
        
        return None
    
    def _generate_response(self, prompt: str) -> str:
        """Generate response using the configured LLM with enhanced error handling."""
        try:
            if self.llm_type == "openai":
                response = self.llm_client.chat.completions.create(
                    model=self.model_name,
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a specialized medical AI assistant with expertise in healthcare data analysis. Provide accurate, precise information based solely on the provided patient records. Always cite specific information and be clear about data limitations."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=self.temperature,
                    max_tokens=self.max_tokens
                )
                return response.choices[0].message.content
                
        except Exception as e:
            return f"Error generating response: {str(e)}"
    
    def _build_rag_prompt(self, query: str, retrieved_docs: List[Dict[str, Any]], patient_info: Optional[Dict[str, str]] = None) -> str:
        """Build comprehensive RAG prompt with enhanced context and instructions."""
        context_parts = []
        
        # Add patient context if available
        if patient_info:
            if patient_info["type"] == "patient_name":
                context_parts.append(f"PATIENT FOCUS: {patient_info['first_name']} {patient_info['last_name']}")
            elif patient_info["type"] == "patient_number":
                context_parts.append(f"PATIENT FOCUS: Patient #{patient_info['patient_number']}")
        
        # Add retrieved documents with enhanced formatting
        if retrieved_docs:
            context_parts.append("RELEVANT PATIENT INFORMATION:")
            for i, doc in enumerate(retrieved_docs, 1):
                patient_name = f"{doc['metadata']['first_name']} {doc['metadata']['last_name']}"
                patient_num = doc['metadata']['patient_number']
                similarity = doc.get('similarity_score', 0)
                chunk_info = f"(Chunk {doc['metadata']['chunk_id'] + 1}/{doc['metadata'].get('total_chunks', 1)})"
                
                context_parts.append(f"\n--- Document {i} ---")
                context_parts.append(f"Patient: {patient_name} (#{patient_num}) {chunk_info}")
                context_parts.append(f"Relevance Score: {similarity:.3f}")
                context_parts.append(f"Content: {doc['content']}")
        else:
            context_parts.append("No relevant patient information found in the database.")
        
        context = "\n".join(context_parts)
        
        prompt = f"""As a healthcare AI assistant, analyze the provided patient information and answer the question with medical precision.

CLINICAL CONTEXT:
{context}

MEDICAL QUESTION: {query}

RESPONSE GUIDELINES:
• Base answers ONLY on the provided patient records
• Include specific patient identifiers (name/number) in your response
• If information is incomplete or unavailable, state this clearly
• Use appropriate medical terminology
• Maintain patient confidentiality principles
• Provide structured, actionable information
• If multiple patients are referenced, clearly distinguish between them

CLINICAL RESPONSE:"""
        
        return prompt
    
    def load_documents(self, force_reload: bool = False, pdf_files_subset: List[str] = None) -> List[PatientDocument]:
        """Load patient documents from PDF directory with enhanced error handling."""
        if self.documents_loaded and not force_reload:
            print("Documents already loaded. Use force_reload=True to reload.")
            return []
        
        if not os.path.exists(self.pdf_directory):
            raise FileNotFoundError(f"PDF directory not found: {self.pdf_directory}")
        
        if pdf_files_subset is not None:
            # Use provided subset of files
            pdf_files = pdf_files_subset
        else:
            # Load all PDF files
            pdf_files = [f for f in os.listdir(self.pdf_directory) if f.endswith('.pdf')]
        
        if not pdf_files:
            print(f"Warning: No PDF files found in {self.pdf_directory}")
            return []
        
        documents = []
        failed_files = []
        
        print(f"Loading {len(pdf_files)} PDF files...")
        
        for filename in tqdm(pdf_files, desc="Loading PDFs"):
            file_path = os.path.join(self.pdf_directory, filename)
            
            try:
                # Extract metadata from filename
                metadata = self._extract_metadata_from_filename(filename)
                if not metadata:
                    print(f"Warning: Could not extract metadata from filename: {filename}")
                    failed_files.append(filename)
                    continue
                
                content = self._extract_text_from_pdf(file_path)
                
                if not content or len(content.strip()) < 50:  # Enhanced content validation
                    print(f"Warning: Insufficient text content in {filename}")
                    failed_files.append(filename)
                    continue
                
                document = PatientDocument(
                    content=content,
                    patient_number=metadata["patient_number"],
                    first_name=metadata["first_name"],
                    last_name=metadata["last_name"],
                    filename=filename,
                    file_path=file_path
                )
                documents.append(document)
                
            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")
                failed_files.append(filename)
        
        self.documents_loaded = True
        
        if failed_files:
            print(f"Failed to process {len(failed_files)} files: {failed_files[:5]}{'...' if len(failed_files) > 5 else ''}")
        
        print(f"Successfully loaded {len(documents)} patient documents")
        return documents
    
    def build_index(self, documents: Optional[List[PatientDocument]] = None, force_rebuild: bool = False) -> bool:
        """Build the RAG index with enhanced monitoring and error handling."""
        try:
            if self.is_built and not force_rebuild:
                print("Index already built. Use force_rebuild=True to rebuild.")
                return True
            
            # Initialize components
            self._initialize_embedding_model()
            self._initialize_vector_db()
            self._initialize_llm()
            
            # Load documents if not provided
            if documents is None:
                if not self.documents_loaded:
                    documents = self.load_documents()
                else:
                    # Documents were already loaded, need to reload them for indexing
                    documents = self.load_documents(force_reload=True)
            
            if not documents:
                print("No documents to index")
                return False
            
            # Reset database if rebuilding
            if force_rebuild:
                current_count = self.collection.count()
                if current_count > 0:
                    print("Rebuilding index - clearing existing data...")
                    self.vector_db.delete_collection("patient_records_agent")
                    self.collection = self.vector_db.get_or_create_collection(
                        name="patient_records_agent",
                        metadata={"hnsw:space": "cosine"}
                    )
            
            print("Chunking documents with smart boundary detection...")
            all_chunks = []
            chunk_stats = {"total_chunks": 0, "avg_chunk_size": 0}
            
            for document in documents:
                chunks = self._chunk_document(document)
                all_chunks.extend(chunks)
                chunk_stats["total_chunks"] += len(chunks)
            
            if not all_chunks:
                print("No chunks generated from documents")
                return False
            
            chunk_stats["avg_chunk_size"] = sum(len(chunk.content) for chunk in all_chunks) / len(all_chunks)
            
            print(f"Generated {len(all_chunks)} chunks from {len(documents)} patients")
            print(f"Average chunk size: {chunk_stats['avg_chunk_size']:.0f} characters")
            
            print("Encoding chunks with BGE embeddings...")
            texts = [chunk.content for chunk in all_chunks]
            embeddings = self.embedding_model.encode(
                texts,
                batch_size=self.batch_size,
                show_progress_bar=True,
                normalize_embeddings=True
            )
            
            print("Adding to vector database...")
            batch_size = 100
            for i in tqdm(range(0, len(all_chunks), batch_size), desc="Adding to DB"):
                batch_chunks = all_chunks[i:i + batch_size]
                batch_embeddings = embeddings[i:i + batch_size]
                
                ids = [f"agent_{chunk.patient_number}_{chunk.chunk_id}" for chunk in batch_chunks]
                documents_batch = [chunk.content for chunk in batch_chunks]
                embeddings_batch = [embedding.tolist() for embedding in batch_embeddings]
                metadatas = [chunk.metadata for chunk in batch_chunks]
                
                self.collection.add(
                    ids=ids,
                    documents=documents_batch,
                    embeddings=embeddings_batch,
                    metadatas=metadatas
                )
            
            self.is_built = True
            print("Healthcare RAG Agent index built successfully!")
            print(f"Index contains {self.collection.count()} chunks from {len(documents)} patients")
            return True
            
        except Exception as e:
            print(f"Error building index: {str(e)}")
            return False
    
    def _hybrid_search(self, question: str) -> Dict[str, Any]:
        """
        Hybrid search that first tries to identify patient by ID from filename,
        then falls back to regular vector search if no specific patient is found.
        """
        if not self.is_built:
            raise RuntimeError("RAG Agent system not built. Call build_index() first.")
        
        # Extract patient information from query
        extracted_patient_info = self._extract_patient_info(question)
        
        if extracted_patient_info and extracted_patient_info["type"] == "patient_number":
            # Direct patient ID search - much faster
            patient_number = extracted_patient_info["patient_number"]
            
            # Check if we have this patient's data by looking for matching filename pattern
            target_pattern = f"Enhanced_Patient_{patient_number.zfill(4)}_"
            matching_files = []
            
            # Get all available patients from metadata
            all_results = self.collection.get(include=["metadatas"])
            if all_results["metadatas"]:
                for metadata in all_results["metadatas"]:
                    if metadata["patient_number"] == patient_number:
                        matching_files.append(metadata["filename"])
                        break
            
            if matching_files:
                # Search only within this patient's data
                return self.query_patient_by_number(question, patient_number)
            else:
                # Patient not found, fall back to regular search
                print(f"Patient {patient_number} not found, falling back to regular search")
                return self.query(question)
        
        elif extracted_patient_info and extracted_patient_info["type"] == "patient_name":
            # Direct patient name search
            first_name = extracted_patient_info["first_name"]
            last_name = extracted_patient_info["last_name"]
            return self.query_patient_by_name(question, first_name, last_name)
        
        else:
            # No specific patient identified, use regular vector search
            return self.query(question)
    
    def query(self, question: str, patient_filter: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Phase 1: Pure vector search across all patients - NO patient filtering for baseline comparison."""
        if not self.is_built:
            raise RuntimeError("RAG Agent system not built. Call build_index() first.")
        
        try:
            # Phase 1: No patient filtering - pure vector search across all patients
            # Encode query
            query_embedding = self._encode_query(question)
            
            # Phase 1: No patient filtering - pure vector search across all patients
            results = self.collection.query(
                query_embeddings=[query_embedding.tolist()],
                n_results=self.k,
                include=["documents", "metadatas", "distances"]
            )
            
            # Format results with enhanced metadata
            retrieved_docs = []
            if results["documents"] and results["documents"][0]:
                for i in range(len(results["documents"][0])):
                    result = {
                        "id": results["ids"][0][i],
                        "content": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "distance": results["distances"][0][i],
                        "similarity_score": 1 - results["distances"][0][i]
                    }
                    retrieved_docs.append(result)
            
            # Build enhanced RAG prompt
            rag_prompt = self._build_rag_prompt(question, retrieved_docs, None)  # Phase 1: No patient info
            
            # Generate response with enhanced LLM
            response = self._generate_response(rag_prompt)
            
            return {
                "query": question,
                "response": response,
                "retrieved_documents": retrieved_docs,
                "patient_info": None,  # Phase 1: No patient filtering
                "patient_filter": None,  # Phase 1: No patient filtering
                "num_retrieved": len(retrieved_docs),
                "llm_type": self.llm_type,
                "model": self.model_name,
                "parameters": {
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens,
                    "k": self.k,
                    "embedding_model": self.embedding_model_name
                }
            }
            
        except Exception as e:
            return {
                "query": question,
                "response": f"Error processing query: {str(e)}",
                "retrieved_documents": [],
                "patient_info": None,
                "patient_filter": None,  # Phase 1: No patient filtering
                "num_retrieved": 0,
                "error": str(e),
                "llm_type": self.llm_type
            }
    
    def query_patient_by_name(self, question: str, first_name: str, last_name: str) -> Dict[str, Any]:
        """Query specific patient by name with enhanced name handling."""
        patient_filter = {
            "first_name": first_name.title().strip(),
            "last_name": last_name.title().strip()
        }
        return self.query(question, patient_filter)
    
    def query_patient_by_number(self, question: str, patient_number: str) -> Dict[str, Any]:
        """Query specific patient by number with enhanced number handling."""
        # Normalize patient number (pad with zeros if needed)
        normalized_number = str(patient_number).zfill(4)
        patient_filter = {"patient_number": normalized_number}
        return self.query(question, patient_filter)
    
    def get_all_patients(self) -> List[Dict[str, str]]:
        """Get comprehensive list of all patients in the system."""
        if not self.is_built:
            raise RuntimeError("RAG Agent system not built. Call build_index() first.")
        
        try:
            results = self.collection.get(include=["metadatas"])
            
            patients = {}
            for metadata in results["metadatas"]:
                patient_key = metadata["patient_number"]
                if patient_key not in patients:
                    patients[patient_key] = {
                        "patient_number": metadata["patient_number"],
                        "first_name": metadata["first_name"],
                        "last_name": metadata["last_name"],
                        "full_name": metadata.get("full_name", f"{metadata['first_name']} {metadata['last_name']}"),
                        "total_chunks": metadata.get("total_chunks", 1),
                        "filename": metadata.get("filename", "")
                    }
            
            # Sort by patient number
            sorted_patients = sorted(patients.values(), key=lambda x: int(x["patient_number"]))
            return sorted_patients
            
        except Exception as e:
            print(f"Error retrieving patient list: {str(e)}")
            return []
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics and health metrics."""
        stats = {
            "system_built": self.is_built,
            "documents_loaded": self.documents_loaded,
            "system_type": "Healthcare RAG Agent",
            "configuration": {
                "pdf_directory": self.pdf_directory,
                "db_path": self.db_path,
                "max_chunk_size": self.max_chunk_size,
                "chunk_overlap": self.chunk_overlap,
                "batch_size": self.batch_size,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "k": self.k,
                "embedding_model": self.embedding_model_name
            }
        }
        
        if self.is_built and self.collection:
            try:
                count = self.collection.count()
                patients = self.get_all_patients()
                
                # Calculate average chunks per patient
                avg_chunks = count / len(patients) if patients else 0
                
                stats.update({
                    "vector_db_stats": {
                        "total_documents": count,
                        "total_patients": len(patients),
                        "avg_chunks_per_patient": round(avg_chunks, 2),
                        "collection_name": "patient_records_agent"
                    },
                    "llm_config": {
                        "llm_type": self.llm_type,
                        "model": self.model_name
                    }
                })
            except Exception as e:
                stats["error"] = str(e)
        
        return stats
    
    def reset_system(self) -> bool:
        """Reset the entire RAG Agent system with enhanced cleanup."""
        try:
            print("Resetting Healthcare RAG Agent system...")
            
            if self.vector_db and self.collection:
                try:
                    self.vector_db.delete_collection("patient_records_agent")
                    print("Vector database collection deleted")
                except:
                    pass  # Collection might not exist
            
            # Reset components
            self.embedding_model = None
            self.vector_db = None
            self.collection = None
            self.llm_client = None
            self.llm_type = None
            
            # Reset state
            self.is_built = False
            self.documents_loaded = False
            
            print("Healthcare RAG Agent system reset successfully")
            return True
            
        except Exception as e:
            print(f"Error resetting system: {str(e)}")
            return False


# Example usage and main function
def main():
    """Enhanced example usage of the Healthcare RAG Agent system."""
    print("=== Healthcare RAG Agent System Demo ===\n")
    
    try:
        # Initialize the agent system
        agent = HealthcareRAGAgent()
        
        # Load documents and build index
        print("Loading documents and building agent index...")
        agent.load_documents()
        success = agent.build_index()
        
        if not success:
            print("Failed to build RAG Agent index")
            return
        
        # Show comprehensive system stats
        stats = agent.get_system_stats()
        print(f"\nAgent System ready!")
        print(f"System Type: {stats['system_type']}")
        print(f"Total chunks: {stats['vector_db_stats']['total_documents']}")
        print(f"Total patients: {stats['vector_db_stats']['total_patients']}")
        print(f"Average chunks per patient: {stats['vector_db_stats']['avg_chunks_per_patient']}")
        print(f"LLM Model: {stats['llm_config']['model']}")
        
        # Enhanced example queries
        print("\n=== Enhanced Example Queries ===")
        
        queries = [
            "What are the most common allergies reported across all patients?",
            "Which medications are frequently prescribed for chronic conditions?",
            "What patterns do you see in patient medical histories?"
        ]
        
        for query in queries:
            print(f"\nQuery: {query}")
            result = agent.query(query)
            print(f"Answer: {result['response']}")
            print(f"Retrieved {result['num_retrieved']} relevant documents")
        
        # Patient-specific query with enhanced detection
        patients = agent.get_all_patients()
        if patients:
            sample_patient = patients[0]
            print(f"\n=== Enhanced Patient-Specific Query ===")
            print(f"Analyzing {sample_patient['full_name']} (#{sample_patient['patient_number']})...")
            
            query = f"What is the complete medical profile for {sample_patient['first_name']} {sample_patient['last_name']}?"
            result = agent.query(query)
            print(f"Query: {query}")
            print(f"Answer: {result['response']}")
            print(f"Patient Detection: {result.get('patient_info', 'Auto-detected')}")
        
        print("\n=== Interactive Agent Mode ===")
        print("Enter queries (type 'quit' to exit):")
        print("Try queries like:")
        print("- 'What allergies does patient Hassan Kim have?'")
        print("- 'What medications is patient number 123 taking?'")
        print("- 'Compare the conditions of patients with diabetes'")
        
        while True:
            try:
                question = input("\nYour question: ").strip()
                if question.lower() in ['quit', 'exit', 'q']:
                    break
                
                if not question:
                    continue
                
                result = agent._hybrid_search(question)
                print(f"Answer: {result['response']}")
                print(f"Documents retrieved: {result['num_retrieved']}")
                print(f"Model used: {result.get('model', 'N/A')}")
                
                if result.get('patient_info'):
                    info = result['patient_info']
                    if info['type'] == 'patient_name':
                        print(f"Detected patient: {info['first_name']} {info['last_name']}")
                    else:
                        print(f"Detected patient number: {info['patient_number']}")
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Error: {str(e)}")
        
        print("\nThank you for using Healthcare RAG Agent!")
        
    except Exception as e:
        print(f"System Error: {str(e)}")
        print("Make sure you have:")
        print("1. Set GROQ_API_KEY or OPENAI_API_KEY in .env file")
        print("2. Patient PDF files in ./data/patients/ directory")
        print("3. Correct filename format: Enhanced_Patient_{number}_{first}_{last}.pdf")


if __name__ == "__main__":
    main()