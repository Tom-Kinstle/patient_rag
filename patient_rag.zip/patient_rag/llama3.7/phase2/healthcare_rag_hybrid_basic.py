"""
Healthcare Hybrid RAG System - Basic Model with 2000 chunk size and Patient ID filtering
Enhanced version of the basic RAG with hybrid search capabilities for patient-specific queries.

Key Features:
- 2000 character chunk size (increased from 1000)
- Patient ID-based filtering before semantic search
- Hybrid approach: ID lookup + semantic retrieval
- Maintains basic RAG architecture with enhancements
"""

import os
import re
import fitz  # PyMuPDF
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from groq import Groq
import openai
from tqdm import tqdm
from dotenv import load_dotenv
import time
import json
from datetime import datetime

# Load environment variables
load_dotenv()


@dataclass
class PatientDocument:
    """Data class representing a patient document with metadata."""
    content: str
    patient_number: str
    first_name: str
    last_name: str
    filename: str
    file_path: str


@dataclass
class TextChunk:
    """Data class representing a chunk of text with associated metadata."""
    content: str
    patient_number: str
    first_name: str
    last_name: str
    filename: str
    chunk_id: int
    start_pos: int
    end_pos: int
    metadata: Dict[str, Any]


class HealthcareHybridRAGBasic:
    """
    Hybrid Healthcare RAG System - Basic Model
    Implements hybrid search with patient ID filtering and 2000-character chunks.
    """
    
    def __init__(
        self,
        pdf_directory: str = "../patients_1000",
        db_path: str = "./chroma_db_hybrid_basic",
        embedding_model: str = "BAAI/bge-large-en-v1.5",
        max_chunk_size: int = 2000,  # Increased chunk size
        chunk_overlap: int = 200,
        batch_size: int = 32,
        temperature: float = 0.1,
        max_tokens: int = 500,
        k: int = 1,
        model_name: str = "llama-3.3-70b-versatile"
    ):
        """
        Initialize the Hybrid Healthcare RAG Basic system.
        """
        self.pdf_directory = pdf_directory
        self.db_path = db_path
        self.embedding_model_name = embedding_model
        self.max_chunk_size = max_chunk_size
        self.chunk_overlap = chunk_overlap
        self.batch_size = batch_size
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.k = k
        self.model_name = model_name
        
        # Initialize components
        self.embedding_model = None
        self.vector_db = None
        self.collection = None
        self.llm_client = None
        self.llm_type = None
        
        # Patient lookup cache for hybrid search
        self.patient_lookup = {}
        
        # System state
        self.is_built = False
        self.documents_loaded = False
        
        # Filename pattern for patient PDFs
        self.filename_pattern = re.compile(
            r"Enhanced_Patient_(\d+)_([^_]+)_([^_.]+)\.pdf"
        )
        
        print(f"Hybrid Healthcare RAG Basic initialized")
        print(f"PDF Directory: {self.pdf_directory}")
        print(f"Database Path: {self.db_path}")
        print(f"Chunk Size: {self.max_chunk_size} (Hybrid Mode), Overlap: {self.chunk_overlap}")
    
    def _validate_api_keys(self) -> None:
        """Validate that required API keys are present."""
        groq_key = os.getenv("GROQ_API_KEY")
        openai_key = os.getenv("OPENAI_API_KEY")
        
        if not groq_key and not openai_key:
            raise ValueError("At least one API key (GROQ_API_KEY or OPENAI_API_KEY) must be provided in .env file")
    
    def _initialize_embedding_model(self) -> None:
        """Initialize the sentence transformer model."""
        if self.embedding_model is None:
            print(f"Loading embedding model: {self.embedding_model_name}")
            try:
                self.embedding_model = SentenceTransformer(self.embedding_model_name)
                print("Embedding model loaded successfully")
            except Exception as e:
                raise Exception(f"Failed to load embedding model: {str(e)}")
    
    def _initialize_vector_db(self) -> None:
        """Initialize ChromaDB vector database."""
        if self.vector_db is None:
            try:
                os.makedirs(self.db_path, exist_ok=True)
                self.vector_db = chromadb.PersistentClient(path=self.db_path)
                self.collection = self.vector_db.get_or_create_collection(
                    name="hybrid_basic_patient_records",
                    metadata={"hnsw:space": "cosine"}
                )
                print(f"ChromaDB initialized at: {self.db_path}")
            except Exception as e:
                raise Exception(f"Failed to initialize ChromaDB: {str(e)}")
    
    def _initialize_llm(self) -> None:
        """Initialize LLM client."""
        if self.llm_client is None:
            self._validate_api_keys()
            
            groq_key = os.getenv("GROQ_API_KEY")
            openai_key = os.getenv("OPENAI_API_KEY")
            
            if groq_key:
                try:
                    self.llm_client = Groq(api_key=groq_key)
                    self.llm_type = "groq"
                    print(f"Initialized Groq client for {self.model_name}")
                except Exception as e:
                    print(f"Failed to initialize Groq: {str(e)}")
                    
            if not self.llm_client and openai_key:
                try:
                    openai.api_key = openai_key
                    self.llm_client = openai
                    self.llm_type = "openai"
                    self.model_name = "gpt-3.5-turbo"
                    print("Initialized OpenAI client (fallback)")
                except Exception as e:
                    print(f"Failed to initialize OpenAI: {str(e)}")
            
            if not self.llm_client:
                raise RuntimeError("No valid LLM client could be initialized")
    
    def _extract_metadata_from_filename(self, filename: str) -> Optional[Dict[str, str]]:
        """Extract patient metadata from filename."""
        match = self.filename_pattern.match(filename)
        if match:
            return {
                "patient_number": match.group(1),
                "first_name": match.group(2),
                "last_name": match.group(3)
            }
        return None
    
    def _extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text content from PDF file."""
        try:
            doc = fitz.open(file_path)
            text_content = ""
            for page_num in range(len(doc)):
                page = doc[page_num]
                text_content += page.get_text()
            doc.close()
            return text_content.strip()
        except Exception as e:
            raise Exception(f"Error reading PDF {file_path}: {str(e)}")
    
    def _find_sentence_boundary(self, text: str, position: int) -> int:
        """Find the nearest sentence boundary to avoid cutting sentences."""
        if position >= len(text):
            return len(text)
        
        # Look for sentence endings within a reasonable window
        search_window = min(200, len(text) - position)  # Increased window for larger chunks
        
        for i in range(position, min(position + search_window, len(text))):
            if text[i] in '.!?':
                if i + 1 < len(text) and text[i + 1] in ' \n\t':
                    return i + 1
        
        # Look backwards if no forward boundary found
        for i in range(position, max(0, position - search_window), -1):
            if text[i] in '.!?':
                if i + 1 < len(text) and text[i + 1] in ' \n\t':
                    return i + 1
        
        return position
    
    def _chunk_document_hybrid(self, document: PatientDocument) -> List[TextChunk]:
        """
        Hybrid chunking strategy: Create exactly one chunk per document if possible,
        otherwise chunk with 2000 character limit.
        """
        content = document.content
        content_length = len(content)
        
        # For hybrid approach: try to keep full document as single chunk if reasonable
        # Otherwise use larger chunks (2000 chars) to maintain more context
        if content_length <= self.max_chunk_size:
            return [TextChunk(
                content=content,
                patient_number=document.patient_number,
                first_name=document.first_name,
                last_name=document.last_name,
                filename=document.filename,
                chunk_id=0,
                start_pos=0,
                end_pos=content_length,
                metadata={
                    "patient_number": document.patient_number,
                    "first_name": document.first_name,
                    "last_name": document.last_name,
                    "full_name": f"{document.first_name} {document.last_name}",
                    "filename": document.filename,
                    "file_path": document.file_path,
                    "chunk_id": 0,
                    "total_chunks": 1,
                    "document_length": content_length,
                    "is_full_document": True
                }
            )]
        
        # For documents larger than 2000 chars, chunk with larger size
        chunks = []
        chunk_id = 0
        start_pos = 0
        
        while start_pos < content_length:
            end_pos = min(start_pos + self.max_chunk_size, content_length)
            
            if end_pos < content_length:
                end_pos = self._find_sentence_boundary(content, end_pos)
            
            chunk_content = content[start_pos:end_pos].strip()
            
            if chunk_content:
                chunk = TextChunk(
                    content=chunk_content,
                    patient_number=document.patient_number,
                    first_name=document.first_name,
                    last_name=document.last_name,
                    filename=document.filename,
                    chunk_id=chunk_id,
                    start_pos=start_pos,
                    end_pos=end_pos,
                    metadata={
                        "patient_number": document.patient_number,
                        "first_name": document.first_name,
                        "last_name": document.last_name,
                        "full_name": f"{document.first_name} {document.last_name}",
                        "filename": document.filename,
                        "file_path": document.file_path,
                        "chunk_id": chunk_id,
                        "document_length": content_length,
                        "chunk_length": len(chunk_content),
                        "is_full_document": False
                    }
                )
                chunks.append(chunk)
                chunk_id += 1
            
            if end_pos >= content_length:
                break
            
            start_pos = max(end_pos - self.chunk_overlap, start_pos + 1)
        
        # Add total chunks count to all chunk metadata
        for chunk in chunks:
            chunk.metadata["total_chunks"] = len(chunks)
        
        return chunks
    
    def _build_patient_lookup(self, documents: List[PatientDocument]) -> None:
        """Build patient lookup index for hybrid search."""
        self.patient_lookup = {}
        
        for doc in documents:
            patient_key = doc.patient_number
            name_key = f"{doc.first_name.lower()}_{doc.last_name.lower()}"
            
            self.patient_lookup[patient_key] = {
                "patient_number": doc.patient_number,
                "first_name": doc.first_name,
                "last_name": doc.last_name,
                "full_name": f"{doc.first_name} {doc.last_name}",
                "filename": doc.filename
            }
            
            # Also index by name for lookup
            self.patient_lookup[name_key] = self.patient_lookup[patient_key]
        
        print(f"Built patient lookup index with {len(set(d['patient_number'] for d in self.patient_lookup.values()))} unique patients")
    
    def _encode_query(self, query: str) -> np.ndarray:
        """Encode a query string for similarity search."""
        if not query or not query.strip():
            raise ValueError("Query cannot be empty")
        
        # Add instruction prefix for BGE models to improve retrieval
        prefixed_query = f"Represent this sentence for searching relevant passages: {query.strip()}"
        
        embeddings = self.embedding_model.encode([prefixed_query], normalize_embeddings=True)
        return embeddings[0]
    
    def _extract_patient_info_hybrid(self, query: str) -> Optional[Dict[str, str]]:
        """Enhanced patient information extraction for hybrid search."""
        query_lower = query.lower()
        
        # Pattern for patient number with more variations
        patient_num_patterns = [
            r'patient\s+(?:number\s+|#\s*)?(\d+)',
            r'patient\s+id\s*:?\s*(\d+)',
            r'id\s*:?\s*(\d+)',
            r'number\s+(\d+)',
            r'pt\s*\.?\s*(\d+)'
        ]
        
        for pattern in patient_num_patterns:
            match = re.search(pattern, query_lower)
            if match:
                patient_num = match.group(1).zfill(4)
                return {
                    "type": "patient_number",
                    "patient_number": patient_num
                }
        
        # Enhanced name patterns for better extraction
        name_patterns = [
            r'patient\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'([A-Za-z]+)\s+([A-Za-z]+)(?:\s+patient|\s+has|\s+is)',
            r'for\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'about\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'does\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'([A-Za-z]+)\s+([A-Za-z]+)\'s?',
            r'mr\.?\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'ms\.?\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'mrs\.?\s+([A-Za-z]+)\s+([A-Za-z]+)'
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                first_name = match.group(1).strip()
                last_name = match.group(2).strip()
                
                # Enhanced filtering of medical/common words
                excluded_words = {
                    'patient', 'doctor', 'the', 'has', 'have', 'does', 'what', 'when', 
                    'where', 'how', 'allergies', 'medications', 'condition', 'medical',
                    'history', 'record', 'information', 'data', 'treatment', 'diagnosis',
                    'symptoms', 'chronic', 'acute', 'severe', 'mild', 'taking', 'prescribed'
                }
                
                if (first_name.lower() not in excluded_words and 
                    last_name.lower() not in excluded_words and
                    len(first_name) > 2 and len(last_name) > 2):
                    return {
                        "type": "patient_name",
                        "first_name": first_name.title(),
                        "last_name": last_name.title()
                    }
        
        return None
    
    def _hybrid_patient_search(self, query: str, patient_info: Optional[Dict[str, str]] = None) -> Optional[str]:
        """
        Hybrid search: First identify patient, then search within their records.
        Returns patient_number if found.
        """
        if not patient_info:
            return None
        
        if patient_info["type"] == "patient_number":
            patient_num = patient_info["patient_number"]
            if patient_num in self.patient_lookup:
                return patient_num
        
        elif patient_info["type"] == "patient_name":
            first_name = patient_info["first_name"]
            last_name = patient_info["last_name"]
            name_key = f"{first_name.lower()}_{last_name.lower()}"
            
            if name_key in self.patient_lookup:
                return self.patient_lookup[name_key]["patient_number"]
        
        return None
    
    def _generate_response(self, prompt: str) -> str:
        """Generate response using the configured LLM."""
        try:
            if self.llm_type == "groq":
                chat_completion = self.llm_client.chat.completions.create(
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful medical assistant that provides accurate information based on patient records. Always be precise and cite specific information from the provided context."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    model=self.model_name,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    top_p=1,
                    stream=False,
                    stop=None,
                )
                return chat_completion.choices[0].message.content
                
            elif self.llm_type == "openai":
                response = self.llm_client.ChatCompletion.create(
                    model=self.model_name,
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful medical assistant that provides accurate information based on patient records. Always be precise and cite specific information from the provided context."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=self.temperature,
                    max_tokens=self.max_tokens
                )
                return response.choices[0].message.content
                
        except Exception as e:
            return f"Error generating response: {str(e)}"
    
    def _build_rag_prompt(self, query: str, retrieved_docs: List[Dict[str, Any]], patient_info: Optional[Dict[str, str]] = None) -> str:
        """Build RAG prompt with retrieved documents and patient context."""
        context_parts = []
        
        # Add patient context if available
        if patient_info:
            if patient_info["type"] == "patient_name":
                context_parts.append(f"Query is about patient: {patient_info['first_name']} {patient_info['last_name']}")
            elif patient_info["type"] == "patient_number":
                context_parts.append(f"Query is about patient number: {patient_info['patient_number']}")
        
        # Add retrieved documents
        if retrieved_docs:
            context_parts.append("Relevant patient information:")
            for i, doc in enumerate(retrieved_docs, 1):
                patient_name = f"{doc['metadata']['first_name']} {doc['metadata']['last_name']}"
                patient_num = doc['metadata']['patient_number']
                similarity = doc.get('similarity_score', 0)
                
                context_parts.append(f"\nDocument {i} (Patient: {patient_name}, Number: {patient_num}, Relevance: {similarity:.3f}):")
                context_parts.append(doc['content'])
        else:
            context_parts.append("No relevant patient information found.")
        
        context = "\n".join(context_parts)
        
        prompt = f"""Based on the following patient information, please answer the question accurately and concisely.

CONTEXT:
{context}

QUESTION: {query}

INSTRUCTIONS:
- Only use information provided in the context
- Be specific about which patient the information relates to
- If the information is not available in the context, clearly state that
- Include patient name and number when relevant
- Keep the response focused and medical professional

ANSWER:"""
        
        return prompt
    
    def load_documents(self, force_reload: bool = False) -> List[PatientDocument]:
        """Load patient documents from PDF directory."""
        if self.documents_loaded and not force_reload:
            print("Documents already loaded. Use force_reload=True to reload.")
            return []
        
        if not os.path.exists(self.pdf_directory):
            raise FileNotFoundError(f"PDF directory not found: {self.pdf_directory}")
        
        pdf_files = [f for f in os.listdir(self.pdf_directory) if f.endswith('.pdf')]
        
        if not pdf_files:
            print(f"Warning: No PDF files found in {self.pdf_directory}")
            return []
        
        documents = []
        print(f"Loading {len(pdf_files)} PDF files...")
        
        for filename in tqdm(pdf_files, desc="Loading PDFs"):
            file_path = os.path.join(self.pdf_directory, filename)
            
            # Extract metadata from filename
            metadata = self._extract_metadata_from_filename(filename)
            if not metadata:
                print(f"Warning: Could not extract metadata from filename: {filename}")
                continue
            
            try:
                content = self._extract_text_from_pdf(file_path)
                
                if not content:
                    print(f"Warning: No text content found in {filename}")
                    continue
                
                document = PatientDocument(
                    content=content,
                    patient_number=metadata["patient_number"],
                    first_name=metadata["first_name"],
                    last_name=metadata["last_name"],
                    filename=filename,
                    file_path=file_path
                )
                documents.append(document)
                
            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")
        
        self.documents_loaded = True
        print(f"Successfully loaded {len(documents)} patient documents")
        
        # Build patient lookup for hybrid search
        self._build_patient_lookup(documents)
        
        return documents
    
    def build_index(self, documents: Optional[List[PatientDocument]] = None, force_rebuild: bool = False) -> bool:
        """Build the hybrid RAG index from patient documents."""
        try:
            if self.is_built and not force_rebuild:
                print("Index already built. Use force_rebuild=True to rebuild.")
                return True
            
            # Initialize components
            self._initialize_embedding_model()
            self._initialize_vector_db()
            self._initialize_llm()
            
            # Load documents if not provided
            if documents is None:
                documents = self.load_documents()
            
            if not documents:
                print("No documents to index")
                return False
            
            # Reset database if rebuilding
            if force_rebuild:
                current_count = self.collection.count()
                if current_count > 0:
                    print("Rebuilding index - clearing existing data...")
                    self.vector_db.delete_collection("hybrid_basic_patient_records")
                    self.collection = self.vector_db.get_or_create_collection(
                        name="hybrid_basic_patient_records",
                        metadata={"hnsw:space": "cosine"}
                    )
            
            print("Hybrid chunking with 2000 character limit...")
            all_chunks = []
            full_doc_count = 0
            
            for document in tqdm(documents, desc="Processing documents"):
                chunks = self._chunk_document_hybrid(document)
                all_chunks.extend(chunks)
                
                # Count full documents vs chunked documents
                if len(chunks) == 1 and chunks[0].metadata.get("is_full_document", False):
                    full_doc_count += 1
            
            if not all_chunks:
                print("No chunks generated from documents")
                return False
            
            print(f"Hybrid processing complete:")
            print(f"  - {len(documents)} total documents processed")
            print(f"  - {len(all_chunks)} total chunks generated")
            print(f"  - {full_doc_count} kept as full documents")
            print(f"  - {len(documents) - full_doc_count} split into multiple chunks")
            
            print("Encoding chunks...")
            texts = [chunk.content for chunk in all_chunks]
            embeddings = self.embedding_model.encode(
                texts,
                batch_size=self.batch_size,
                show_progress_bar=True,
                normalize_embeddings=True
            )
            
            print("Adding to vector database...")
            batch_size = 100
            for i in tqdm(range(0, len(all_chunks), batch_size), desc="Adding to DB"):
                batch_chunks = all_chunks[i:i + batch_size]
                batch_embeddings = embeddings[i:i + batch_size]
                
                ids = [f"hybrid_basic_{chunk.patient_number}_{chunk.chunk_id}" for chunk in batch_chunks]
                documents_batch = [chunk.content for chunk in batch_chunks]
                embeddings_batch = [embedding.tolist() for embedding in batch_embeddings]
                metadatas = [chunk.metadata for chunk in batch_chunks]
                
                self.collection.add(
                    ids=ids,
                    documents=documents_batch,
                    embeddings=embeddings_batch,
                    metadatas=metadatas
                )
            
            self.is_built = True
            print("Hybrid Healthcare RAG Basic index built successfully!")
            return True
            
        except Exception as e:
            print(f"Error building index: {str(e)}")
            return False
    
    def query(self, question: str, patient_filter: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Query the hybrid RAG system with patient-aware search."""
        if not self.is_built:
            raise RuntimeError("RAG system not built. Call build_index() first.")
        
        start_time = time.time()
        
        try:
            # Extract patient information from query if not explicitly filtered
            extracted_patient_info = None
            target_patient_number = None
            
            if not patient_filter:
                extracted_patient_info = self._extract_patient_info_hybrid(question)
                if extracted_patient_info:
                    target_patient_number = self._hybrid_patient_search(question, extracted_patient_info)
                    
                    if target_patient_number:
                        patient_filter = {"patient_number": target_patient_number}
            
            # Encode query
            query_embedding = self._encode_query(question)
            
            # Build where clause for patient filtering
            where_clause = None
            if patient_filter:
                where_clause = {}
                if "patient_number" in patient_filter:
                    where_clause["patient_number"] = patient_filter["patient_number"]
                if "first_name" in patient_filter and "last_name" in patient_filter:
                    where_clause["first_name"] = patient_filter["first_name"]
                    where_clause["last_name"] = patient_filter["last_name"]
            
            # Retrieve relevant documents
            results = self.collection.query(
                query_embeddings=[query_embedding.tolist()],
                n_results=self.k,
                where=where_clause,
                include=["documents", "metadatas", "distances"]
            )
            
            # Format results
            retrieved_docs = []
            if results["documents"] and results["documents"][0]:
                for i in range(len(results["documents"][0])):
                    result = {
                        "id": results["ids"][0][i],
                        "content": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "distance": results["distances"][0][i],
                        "similarity_score": 1 - results["distances"][0][i]
                    }
                    retrieved_docs.append(result)
            
            # Build RAG prompt
            rag_prompt = self._build_rag_prompt(question, retrieved_docs, extracted_patient_info)
            
            # Generate response
            response = self._generate_response(rag_prompt)
            
            end_time = time.time()
            response_time = end_time - start_time
            
            return {
                "query": question,
                "response": response,
                "retrieved_documents": retrieved_docs,
                "patient_info": extracted_patient_info,
                "patient_filter": patient_filter,
                "target_patient_number": target_patient_number,
                "num_retrieved": len(retrieved_docs),
                "llm_type": self.llm_type,
                "model_name": self.model_name,
                "response_time": response_time,
                "parameters": {
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens,
                    "k": self.k,
                    "chunk_size": self.max_chunk_size,
                    "hybrid_search": True
                }
            }
            
        except Exception as e:
            end_time = time.time()
            response_time = end_time - start_time
            
            return {
                "query": question,
                "response": f"Error processing query: {str(e)}",
                "retrieved_documents": [],
                "patient_info": None,
                "patient_filter": patient_filter,
                "target_patient_number": None,
                "num_retrieved": 0,
                "response_time": response_time,
                "error": str(e)
            }
    
    def query_patient_by_name(self, question: str, first_name: str, last_name: str) -> Dict[str, Any]:
        """Query specific patient by name with hybrid search."""
        patient_filter = {
            "first_name": first_name.title(),
            "last_name": last_name.title()
        }
        return self.query(question, patient_filter)
    
    def query_patient_by_number(self, question: str, patient_number: str) -> Dict[str, Any]:
        """Query specific patient by number with hybrid search."""
        patient_filter = {"patient_number": str(patient_number).zfill(4)}
        return self.query(question, patient_filter)
    
    def get_all_patients(self) -> List[Dict[str, str]]:
        """Get list of all patients in the system."""
        if not self.is_built:
            raise RuntimeError("RAG system not built. Call build_index() first.")
        
        try:
            results = self.collection.get(include=["metadatas"])
            
            patients = {}
            for metadata in results["metadatas"]:
                patient_key = metadata["patient_number"]
                if patient_key not in patients:
                    patients[patient_key] = {
                        "patient_number": metadata["patient_number"],
                        "first_name": metadata["first_name"],
                        "last_name": metadata["last_name"],
                        "full_name": metadata.get("full_name", f"{metadata['first_name']} {metadata['last_name']}")
                    }
            
            return list(patients.values())
            
        except Exception as e:
            print(f"Error retrieving patient list: {str(e)}")
            return []
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics."""
        stats = {
            "model_type": "Hybrid Healthcare RAG Basic",
            "model_name": self.model_name,
            "system_built": self.is_built,
            "documents_loaded": self.documents_loaded,
            "hybrid_search_enabled": True,
            "configuration": {
                "pdf_directory": self.pdf_directory,
                "db_path": self.db_path,
                "max_chunk_size": self.max_chunk_size,
                "chunk_overlap": self.chunk_overlap,
                "batch_size": self.batch_size,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "k": self.k,
                "embedding_model": self.embedding_model_name
            }
        }
        
        if self.is_built and self.collection:
            try:
                count = self.collection.count()
                patients = self.get_all_patients()
                
                stats.update({
                    "vector_db_stats": {
                        "total_documents": count,
                        "total_patients": len(patients),
                        "avg_chunks_per_patient": count / len(patients) if patients else 0,
                        "patient_lookup_entries": len(self.patient_lookup)
                    },
                    "llm_type": self.llm_type
                })
            except Exception as e:
                stats["error"] = str(e)
        
        return stats
    
    def reset_system(self) -> bool:
        """Reset the entire RAG system."""
        try:
            print("Resetting Hybrid Healthcare RAG Basic system...")
            
            if self.vector_db and self.collection:
                self.vector_db.delete_collection("hybrid_basic_patient_records")
            
            # Reset components
            self.embedding_model = None
            self.vector_db = None
            self.collection = None
            self.llm_client = None
            self.patient_lookup = {}
            
            # Reset state
            self.is_built = False
            self.documents_loaded = False
            
            print("Hybrid Healthcare RAG Basic system reset successfully")
            return True
            
        except Exception as e:
            print(f"Error resetting system: {str(e)}")
            return False


def main():
    """Example usage of the Hybrid Healthcare RAG Basic system."""
    print("=== Hybrid Healthcare RAG Basic Demo ===\n")
    
    try:
        # Initialize the hybrid system
        hybrid_rag = HealthcareHybridRAGBasic()
        
        # Load documents and build index
        print("Loading documents and building hybrid index...")
        hybrid_rag.load_documents()
        success = hybrid_rag.build_index()
        
        if not success:
            print("Failed to build Hybrid RAG Basic index")
            return
        
        # Show system stats
        stats = hybrid_rag.get_system_stats()
        print(f"\nHybrid Healthcare RAG Basic ready!")
        print(f"Model: {stats['model_name']}")
        print(f"Total chunks: {stats['vector_db_stats']['total_documents']}")
        print(f"Total patients: {stats['vector_db_stats']['total_patients']}")
        print(f"Avg chunks per patient: {stats['vector_db_stats']['avg_chunks_per_patient']:.1f}")
        
        print("\n=== Hybrid system ready for testing ===")
        
    except Exception as e:
        print(f"Error initializing Hybrid RAG Basic: {str(e)}")


if __name__ == "__main__":
    main()