"""
Healthcare RAG System - Complete implementation in a single file
A comprehensive Retrieval-Augmented Generation system for healthcare patient data.

Usage:
    from healthcare_rag import HealthcareRAG
    
    rag = HealthcareRAG()
    rag.load_documents()
    rag.build_index()
    
    result = rag.query("What allergies does patient John Doe have?")
    print(result['response'])
"""

import os
import re
import fitz  # PyMuPDF
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from groq import Groq
import openai
from tqdm import tqdm
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


@dataclass
class PatientDocument:
    """Data class representing a patient document with metadata."""
    content: str
    patient_number: str
    first_name: str
    last_name: str
    filename: str
    file_path: str


@dataclass
class TextChunk:
    """Data class representing a chunk of text with associated metadata."""
    content: str
    patient_number: str
    first_name: str
    last_name: str
    filename: str
    chunk_id: int
    start_pos: int
    end_pos: int
    metadata: Dict[str, Any]


class HealthcareRAG:
    """
    Complete Healthcare RAG system for querying patient records.
    Handles PDF loading, chunking, embedding, vector storage, and LLM querying.
    """
    
    def __init__(
        self,
        pdf_directory: str = "./data/patients",
        db_path: str = "./chroma_db",
        embedding_model: str = "BAAI/bge-large-en-v1.5",
        max_chunk_size: int = 1000,
        chunk_overlap: int = 200,
        batch_size: int = 32,
        temperature: float = 0.1,
        max_tokens: int = 500,
        k: int = 1
    ):
        """
        Initialize the Healthcare RAG system.
        
        Args:
            pdf_directory: Path to directory containing patient PDFs
            db_path: Path for ChromaDB storage
            embedding_model: HuggingFace model for embeddings
            max_chunk_size: Maximum size of text chunks
            chunk_overlap: Overlap between chunks
            batch_size: Batch size for processing
            temperature: LLM temperature
            max_tokens: Maximum tokens in LLM response
            k: Number of documents to retrieve
        """
        self.pdf_directory = pdf_directory
        self.db_path = db_path
        self.embedding_model_name = embedding_model
        self.max_chunk_size = max_chunk_size
        self.chunk_overlap = chunk_overlap
        self.batch_size = batch_size
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.k = k
        
        # Initialize components
        self.embedding_model = None
        self.vector_db = None
        self.collection = None
        self.llm_client = None
        self.llm_type = None
        
        # System state
        self.is_built = False
        self.documents_loaded = False
        
        # Filename pattern for patient PDFs
        self.filename_pattern = re.compile(
            r"Enhanced_Patient_(\d+)_([^_]+)_([^_.]+)\.pdf"
        )
        
        print(f"Healthcare RAG System initialized")
        print(f"PDF Directory: {self.pdf_directory}")
        print(f"Database Path: {self.db_path}")
        print(f"Chunk Size: {self.max_chunk_size}, Overlap: {self.chunk_overlap}")
    
    def _validate_api_keys(self) -> None:
        """Validate that required API keys are present."""
        groq_key = os.getenv("GROQ_API_KEY")
        openai_key = os.getenv("OPENAI_API_KEY")
        
        if not groq_key and not openai_key:
            raise ValueError("At least one API key (GROQ_API_KEY or OPENAI_API_KEY) must be provided in .env file")
    
    def _initialize_embedding_model(self) -> None:
        """Initialize the sentence transformer model."""
        if self.embedding_model is None:
            print(f"Loading embedding model: {self.embedding_model_name}")
            try:
                self.embedding_model = SentenceTransformer(self.embedding_model_name)
                print("Embedding model loaded successfully")
            except Exception as e:
                raise Exception(f"Failed to load embedding model: {str(e)}")
    
    def _initialize_vector_db(self) -> None:
        """Initialize ChromaDB vector database."""
        if self.vector_db is None:
            try:
                os.makedirs(self.db_path, exist_ok=True)
                self.vector_db = chromadb.PersistentClient(path=self.db_path)
                self.collection = self.vector_db.get_or_create_collection(
                    name="patient_records",
                    metadata={"hnsw:space": "cosine"}
                )
                print(f"ChromaDB initialized at: {self.db_path}")
            except Exception as e:
                raise Exception(f"Failed to initialize ChromaDB: {str(e)}")
    
    def _initialize_llm(self) -> None:
        """Initialize LLM client."""
        if self.llm_client is None:
            self._validate_api_keys()
            
            groq_key = os.getenv("GROQ_API_KEY")
            openai_key = os.getenv("OPENAI_API_KEY")
            
            if groq_key:
                try:
                    self.llm_client = Groq(api_key=groq_key)
                    self.llm_type = "groq"
                    print("Initialized Groq client for Llama 3")
                except Exception as e:
                    print(f"Failed to initialize Groq: {str(e)}")
                    
            if not self.llm_client and openai_key:
                try:
                    openai.api_key = openai_key
                    self.llm_client = openai
                    self.llm_type = "openai"
                    print("Initialized OpenAI client")
                except Exception as e:
                    print(f"Failed to initialize OpenAI: {str(e)}")
            
            if not self.llm_client:
                raise RuntimeError("No valid LLM client could be initialized")
    
    def _extract_metadata_from_filename(self, filename: str) -> Optional[Dict[str, str]]:
        """Extract patient metadata from filename."""
        match = self.filename_pattern.match(filename)
        if match:
            return {
                "patient_number": match.group(1),
                "first_name": match.group(2),
                "last_name": match.group(3)
            }
        return None
    
    def _extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text content from PDF file."""
        try:
            doc = fitz.open(file_path)
            text_content = ""
            for page_num in range(len(doc)):
                page = doc[page_num]
                text_content += page.get_text()
            doc.close()
            return text_content.strip()
        except Exception as e:
            raise Exception(f"Error reading PDF {file_path}: {str(e)}")
    
    def _find_sentence_boundary(self, text: str, position: int) -> int:
        """Find the nearest sentence boundary to avoid cutting sentences."""
        if position >= len(text):
            return len(text)
        
        # Look for sentence endings within a reasonable window
        search_window = min(100, len(text) - position)
        
        for i in range(position, min(position + search_window, len(text))):
            if text[i] in '.!?':
                if i + 1 < len(text) and text[i + 1] in ' \n\t':
                    return i + 1
        
        # Look backwards if no forward boundary found
        for i in range(position, max(0, position - search_window), -1):
            if text[i] in '.!?':
                if i + 1 < len(text) and text[i + 1] in ' \n\t':
                    return i + 1
        
        return position
    
    def _chunk_document(self, document: PatientDocument) -> List[TextChunk]:
        """Split a patient document into chunks."""
        content = document.content
        content_length = len(content)
        
        # If document is shorter than max chunk size, return as single chunk
        if content_length <= self.max_chunk_size:
            return [TextChunk(
                content=content,
                patient_number=document.patient_number,
                first_name=document.first_name,
                last_name=document.last_name,
                filename=document.filename,
                chunk_id=0,
                start_pos=0,
                end_pos=content_length,
                metadata={
                    "patient_number": document.patient_number,
                    "first_name": document.first_name,
                    "last_name": document.last_name,
                    "full_name": f"{document.first_name} {document.last_name}",
                    "filename": document.filename,
                    "file_path": document.file_path,
                    "chunk_id": 0,
                    "total_chunks": 1,
                    "document_length": content_length
                }
            )]
        
        chunks = []
        chunk_id = 0
        start_pos = 0
        
        while start_pos < content_length:
            end_pos = min(start_pos + self.max_chunk_size, content_length)
            
            if end_pos < content_length:
                end_pos = self._find_sentence_boundary(content, end_pos)
            
            chunk_content = content[start_pos:end_pos].strip()
            
            if chunk_content:
                chunk = TextChunk(
                    content=chunk_content,
                    patient_number=document.patient_number,
                    first_name=document.first_name,
                    last_name=document.last_name,
                    filename=document.filename,
                    chunk_id=chunk_id,
                    start_pos=start_pos,
                    end_pos=end_pos,
                    metadata={
                        "patient_number": document.patient_number,
                        "first_name": document.first_name,
                        "last_name": document.last_name,
                        "full_name": f"{document.first_name} {document.last_name}",
                        "filename": document.filename,
                        "file_path": document.file_path,
                        "chunk_id": chunk_id,
                        "document_length": content_length,
                        "chunk_length": len(chunk_content)
                    }
                )
                chunks.append(chunk)
                chunk_id += 1
            
            if end_pos >= content_length:
                break
            
            start_pos = max(end_pos - self.chunk_overlap, start_pos + 1)
        
        # Add total chunks count to all chunk metadata
        for chunk in chunks:
            chunk.metadata["total_chunks"] = len(chunks)
        
        return chunks
    
    def _encode_query(self, query: str) -> np.ndarray:
        """Encode a query string for similarity search."""
        if not query or not query.strip():
            raise ValueError("Query cannot be empty")
        
        # Add instruction prefix for BGE models to improve retrieval
        prefixed_query = f"Represent this sentence for searching relevant passages: {query.strip()}"
        
        embeddings = self.embedding_model.encode([prefixed_query], normalize_embeddings=True)
        return embeddings[0]
    
    def _extract_patient_info(self, query: str) -> Optional[Dict[str, str]]:
        """Extract patient information from query using pattern matching."""
        query_lower = query.lower()
        
        # Pattern for patient number
        patient_num_pattern = r'patient\s+(?:number\s+)?(\d+)'
        patient_num_match = re.search(patient_num_pattern, query_lower)
        
        if patient_num_match:
            return {
                "type": "patient_number",
                "patient_number": patient_num_match.group(1)
            }
        
        # Pattern for patient name
        name_patterns = [
            r'patient\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'([A-Za-z]+)\s+([A-Za-z]+)(?:\s+patient|\s+has|\s+is)',
            r'for\s+([A-Za-z]+)\s+([A-Za-z]+)',
            r'about\s+([A-Za-z]+)\s+([A-Za-z]+)'
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, query, re.IGNORECASE)
            if match:
                first_name = match.group(1).strip()
                last_name = match.group(2).strip()
                
                # Filter out common words
                common_words = {'patient', 'doctor', 'the', 'has', 'have', 'does', 'what', 'when', 'where', 'how'}
                if first_name.lower() not in common_words and last_name.lower() not in common_words:
                    return {
                        "type": "patient_name",
                        "first_name": first_name.title(),
                        "last_name": last_name.title()
                    }
        
        return None
    
    def _generate_response(self, prompt: str) -> str:
        """Generate response using the configured LLM."""
        try:
            if self.llm_type == "groq":
                chat_completion = self.llm_client.chat.completions.create(
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful medical assistant that provides accurate information based on patient records. Always be precise and cite specific information from the provided context."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    model="llama-3.3-70b-versatile",
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    top_p=1,
                    stream=False,
                    stop=None,
                )
                return chat_completion.choices[0].message.content
                
            elif self.llm_type == "openai":
                response = self.llm_client.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful medical assistant that provides accurate information based on patient records. Always be precise and cite specific information from the provided context."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=self.temperature,
                    max_tokens=self.max_tokens
                )
                return response.choices[0].message.content
                
        except Exception as e:
            return f"Error generating response: {str(e)}"
    
    def _build_rag_prompt(self, query: str, retrieved_docs: List[Dict[str, Any]], patient_info: Optional[Dict[str, str]] = None) -> str:
        """Build RAG prompt with retrieved documents and patient context."""
        context_parts = []
        
        # Add patient context if available
        if patient_info:
            if patient_info["type"] == "patient_name":
                context_parts.append(f"Query is about patient: {patient_info['first_name']} {patient_info['last_name']}")
            elif patient_info["type"] == "patient_number":
                context_parts.append(f"Query is about patient number: {patient_info['patient_number']}")
        
        # Add retrieved documents
        if retrieved_docs:
            context_parts.append("Relevant patient information:")
            for i, doc in enumerate(retrieved_docs, 1):
                patient_name = f"{doc['metadata']['first_name']} {doc['metadata']['last_name']}"
                patient_num = doc['metadata']['patient_number']
                similarity = doc.get('similarity_score', 0)
                
                context_parts.append(f"\nDocument {i} (Patient: {patient_name}, Number: {patient_num}, Relevance: {similarity:.3f}):")
                context_parts.append(doc['content'])
        else:
            context_parts.append("No relevant patient information found.")
        
        context = "\n".join(context_parts)
        
        prompt = f"""Based on the following patient information, please answer the question accurately and concisely.

CONTEXT:
{context}

QUESTION: {query}

INSTRUCTIONS:
- Only use information provided in the context
- Be specific about which patient the information relates to
- If the information is not available in the context, clearly state that
- Include patient name and number when relevant
- Keep the response focused and medical professional

ANSWER:"""
        
        return prompt
    
    def load_documents(self, force_reload: bool = False) -> List[PatientDocument]:
        """Load patient documents from PDF directory."""
        if self.documents_loaded and not force_reload:
            print("Documents already loaded. Use force_reload=True to reload.")
            return []
        
        if not os.path.exists(self.pdf_directory):
            raise FileNotFoundError(f"PDF directory not found: {self.pdf_directory}")
        
        pdf_files = [f for f in os.listdir(self.pdf_directory) if f.endswith('.pdf')]
        
        if not pdf_files:
            print(f"Warning: No PDF files found in {self.pdf_directory}")
            return []
        
        documents = []
        print(f"Loading {len(pdf_files)} PDF files...")
        
        for filename in tqdm(pdf_files, desc="Loading PDFs"):
            file_path = os.path.join(self.pdf_directory, filename)
            
            # Extract metadata from filename
            metadata = self._extract_metadata_from_filename(filename)
            if not metadata:
                print(f"Warning: Could not extract metadata from filename: {filename}")
                continue
            
            try:
                content = self._extract_text_from_pdf(file_path)
                
                if not content:
                    print(f"Warning: No text content found in {filename}")
                    continue
                
                document = PatientDocument(
                    content=content,
                    patient_number=metadata["patient_number"],
                    first_name=metadata["first_name"],
                    last_name=metadata["last_name"],
                    filename=filename,
                    file_path=file_path
                )
                documents.append(document)
                
            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")
        
        self.documents_loaded = True
        print(f"Successfully loaded {len(documents)} patient documents")
        return documents
    
    def build_index(self, documents: Optional[List[PatientDocument]] = None, force_rebuild: bool = False) -> bool:
        """Build the RAG index from patient documents."""
        try:
            if self.is_built and not force_rebuild:
                print("Index already built. Use force_rebuild=True to rebuild.")
                return True
            
            # Initialize components
            self._initialize_embedding_model()
            self._initialize_vector_db()
            self._initialize_llm()
            
            # Load documents if not provided
            if documents is None:
                documents = self.load_documents()
            
            if not documents:
                print("No documents to index")
                return False
            
            # Reset database if rebuilding
            if force_rebuild:
                current_count = self.collection.count()
                if current_count > 0:
                    print("Rebuilding index - clearing existing data...")
                    self.vector_db.delete_collection("patient_records")
                    self.collection = self.vector_db.get_or_create_collection(
                        name="patient_records",
                        metadata={"hnsw:space": "cosine"}
                    )
            
            print("Chunking documents...")
            all_chunks = []
            for document in documents:
                chunks = self._chunk_document(document)
                all_chunks.extend(chunks)
            
            if not all_chunks:
                print("No chunks generated from documents")
                return False
            
            print(f"Generated {len(all_chunks)} chunks from {len(documents)} patients")
            
            print("Encoding chunks...")
            texts = [chunk.content for chunk in all_chunks]
            embeddings = self.embedding_model.encode(
                texts,
                batch_size=self.batch_size,
                show_progress_bar=True,
                normalize_embeddings=True
            )
            
            print("Adding to vector database...")
            batch_size = 100
            for i in tqdm(range(0, len(all_chunks), batch_size), desc="Adding to DB"):
                batch_chunks = all_chunks[i:i + batch_size]
                batch_embeddings = embeddings[i:i + batch_size]
                
                ids = [f"{chunk.patient_number}_{chunk.chunk_id}" for chunk in batch_chunks]
                documents_batch = [chunk.content for chunk in batch_chunks]
                embeddings_batch = [embedding.tolist() for embedding in batch_embeddings]
                metadatas = [chunk.metadata for chunk in batch_chunks]
                
                self.collection.add(
                    ids=ids,
                    documents=documents_batch,
                    embeddings=embeddings_batch,
                    metadatas=metadatas
                )
            
            self.is_built = True
            print("RAG index built successfully!")
            return True
            
        except Exception as e:
            print(f"Error building index: {str(e)}")
            return False
    
    def query(self, question: str, patient_filter: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Query the RAG system with a question."""
        if not self.is_built:
            raise RuntimeError("RAG system not built. Call build_index() first.")
        
        try:
            # Extract patient information from query if not explicitly filtered
            extracted_patient_info = None
            if not patient_filter:
                extracted_patient_info = self._extract_patient_info(question)
                if extracted_patient_info:
                    if extracted_patient_info["type"] == "patient_name":
                        patient_filter = {
                            "first_name": extracted_patient_info["first_name"],
                            "last_name": extracted_patient_info["last_name"]
                        }
                    elif extracted_patient_info["type"] == "patient_number":
                        patient_filter = {
                            "patient_number": extracted_patient_info["patient_number"]
                        }
            
            # Encode query
            query_embedding = self._encode_query(question)
            
            # Build where clause for patient filtering
            where_clause = None
            if patient_filter:
                where_clause = {}
                if "patient_number" in patient_filter:
                    where_clause["patient_number"] = patient_filter["patient_number"]
                if "first_name" in patient_filter and "last_name" in patient_filter:
                    where_clause["first_name"] = patient_filter["first_name"]
                    where_clause["last_name"] = patient_filter["last_name"]
            
            # Retrieve relevant documents
            results = self.collection.query(
                query_embeddings=[query_embedding.tolist()],
                n_results=self.k,
                where=where_clause,
                include=["documents", "metadatas", "distances"]
            )
            
            # Format results
            retrieved_docs = []
            if results["documents"] and results["documents"][0]:
                for i in range(len(results["documents"][0])):
                    result = {
                        "id": results["ids"][0][i],
                        "content": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "distance": results["distances"][0][i],
                        "similarity_score": 1 - results["distances"][0][i]
                    }
                    retrieved_docs.append(result)
            
            # Build RAG prompt
            rag_prompt = self._build_rag_prompt(question, retrieved_docs, extracted_patient_info)
            
            # Generate response
            response = self._generate_response(rag_prompt)
            
            return {
                "query": question,
                "response": response,
                "retrieved_documents": retrieved_docs,
                "patient_info": extracted_patient_info,
                "patient_filter": patient_filter,
                "num_retrieved": len(retrieved_docs),
                "llm_type": self.llm_type,
                "parameters": {
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens,
                    "k": self.k
                }
            }
            
        except Exception as e:
            return {
                "query": question,
                "response": f"Error processing query: {str(e)}",
                "retrieved_documents": [],
                "patient_info": None,
                "patient_filter": patient_filter,
                "num_retrieved": 0,
                "error": str(e)
            }
    
    def query_patient_by_name(self, question: str, first_name: str, last_name: str) -> Dict[str, Any]:
        """Query specific patient by name."""
        patient_filter = {
            "first_name": first_name.title(),
            "last_name": last_name.title()
        }
        return self.query(question, patient_filter)
    
    def query_patient_by_number(self, question: str, patient_number: str) -> Dict[str, Any]:
        """Query specific patient by number."""
        patient_filter = {"patient_number": str(patient_number)}
        return self.query(question, patient_filter)
    
    def get_all_patients(self) -> List[Dict[str, str]]:
        """Get list of all patients in the system."""
        if not self.is_built:
            raise RuntimeError("RAG system not built. Call build_index() first.")
        
        try:
            results = self.collection.get(include=["metadatas"])
            
            patients = {}
            for metadata in results["metadatas"]:
                patient_key = metadata["patient_number"]
                if patient_key not in patients:
                    patients[patient_key] = {
                        "patient_number": metadata["patient_number"],
                        "first_name": metadata["first_name"],
                        "last_name": metadata["last_name"],
                        "full_name": metadata.get("full_name", f"{metadata['first_name']} {metadata['last_name']}")
                    }
            
            return list(patients.values())
            
        except Exception as e:
            print(f"Error retrieving patient list: {str(e)}")
            return []
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics."""
        stats = {
            "system_built": self.is_built,
            "documents_loaded": self.documents_loaded,
            "configuration": {
                "pdf_directory": self.pdf_directory,
                "db_path": self.db_path,
                "max_chunk_size": self.max_chunk_size,
                "chunk_overlap": self.chunk_overlap,
                "batch_size": self.batch_size,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "k": self.k,
                "embedding_model": self.embedding_model_name
            }
        }
        
        if self.is_built and self.collection:
            try:
                count = self.collection.count()
                patients = self.get_all_patients()
                
                stats.update({
                    "vector_db_stats": {
                        "total_documents": count,
                        "total_patients": len(patients)
                    },
                    "llm_type": self.llm_type
                })
            except Exception as e:
                stats["error"] = str(e)
        
        return stats
    
    def reset_system(self) -> bool:
        """Reset the entire RAG system."""
        try:
            print("Resetting Healthcare RAG system...")
            
            if self.vector_db and self.collection:
                self.vector_db.delete_collection("patient_records")
            
            # Reset components
            self.embedding_model = None
            self.vector_db = None
            self.collection = None
            self.llm_client = None
            
            # Reset state
            self.is_built = False
            self.documents_loaded = False
            
            print("Healthcare RAG system reset successfully")
            return True
            
        except Exception as e:
            print(f"Error resetting system: {str(e)}")
            return False


# Example usage and main function
def main():
    """Example usage of the Healthcare RAG system."""
    print("=== Healthcare RAG System Demo ===\n")
    
    try:
        # Initialize the system
        rag = HealthcareRAG()
        
        # Load documents and build index
        print("Loading documents and building index...")
        rag.load_documents()
        success = rag.build_index()
        
        if not success:
            print("Failed to build RAG index")
            return
        
        # Show system stats
        stats = rag.get_system_stats()
        print(f"\nSystem ready!")
        print(f"Total chunks: {stats['vector_db_stats']['total_documents']}")
        print(f"Total patients: {stats['vector_db_stats']['total_patients']}")
        
        # Example queries
        print("\n=== Example Queries ===")
        
        queries = [
            "What are common allergies mentioned in patient records?",
            "What medications are commonly prescribed?"
        ]
        
        for query in queries:
            print(f"\nQuery: {query}")
            result = rag.query(query)
            print(f"Answer: {result['response']}")
        
        # Patient-specific query example
        patients = rag.get_all_patients()
        if patients:
            sample_patient = patients[0]
            print(f"\n=== Patient-Specific Query ===")
            print(f"Querying {sample_patient['full_name']}...")
            
            query = f"What allergies does {sample_patient['first_name']} {sample_patient['last_name']} have?"
            result = rag.query(query)
            print(f"Query: {query}")
            print(f"Answer: {result['response']}")
        
        print("\n=== Interactive Mode ===")
        print("Enter queries (type 'quit' to exit):")
        
        while True:
            try:
                question = input("\nYour question: ").strip()
                if question.lower() in ['quit', 'exit', 'q']:
                    break
                
                if not question:
                    continue
                
                result = rag.query(question)
                print(f"Answer: {result['response']}")
                print(f"Documents retrieved: {result['num_retrieved']}")
                
                if result.get('patient_info'):
                    info = result['patient_info']
                    if info['type'] == 'patient_name':
                        print(f"Detected patient: {info['first_name']} {info['last_name']}")
                    else:
                        print(f"Detected patient number: {info['patient_number']}")
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Error: {str(e)}")
        
        print("\nGoodbye!")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        print("Make sure you have:")
        print("1. Set GROQ_API_KEY or OPENAI_API_KEY in .env file")
        print("2. Patient PDF files in ./data/patients/ directory")
        print("3. Correct filename format: Enhanced_Patient_{number}_{first}_{last}.pdf")


if __name__ == "__main__":
    main()